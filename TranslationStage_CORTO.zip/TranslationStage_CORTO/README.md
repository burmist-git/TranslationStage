README file 10.03.2016

###############
## FOR CORTO ##
###############

This file provides help information how to use the present GUI for 
controlling 2D translation stages at LAL. The information about 
how to install you can find in install_guide.txt. To run the program open 
the terminal, go to the directory where your installed the software and 
type:

./run_GUINAME.sh /path_to_the_mcr_directory/v81

Then GUI will open and you can use it. First you have to connect to Arduino 
board (in two upper windows you can find TCP/IP information/address of the 
board), click the  button "Connect", wait few seconds and in the tab 
"Information" you will see that the program connected to the board, in 
other case you will have a message about wrong address or bad connection 
(to solve it, just rerun the gui).

MAC address: 0x00 0x0E 0xF0 0x41 0xE4 0xB1
IP  address: 134.158.88.86

Connection of the pins:

--> MOTOR 1:
Motor driver pins:

GND	--> GND
+Vdc	--> +24 V

A+	--> Green motor cable	
A-	--> Black motor cable
B+	--> Red motor cable
B-	--> Blue motor cable

PUL+	--> +5 V
PUL-	--> D3 arduino pin
DIR+	--> +5 V
DIR-	--> D8 arduino pin
ENA+	--> +5 V
ENA-	--> A3 arduino pin

SW1	--> OFF
SW2	--> OFF
SW3	--> ON
SW4	--> OFF
SW5	--> ON
SW6	--> ON
SW7	--> ON
SW8	--> OFF

Stopper switcher:

SW11 (negative direction)
Red cable	--> +5 V
Blue cable	--> GND
Black cable	--> D1

SW12 (positive direction)
Red cable	--> +5 V
Blue cable	--> GND
Black cable	--> D2

--> MOTOR 2:
Motor driver pins:

GND	--> GND
+Vdc	--> +24 V

A+	--> Green motor cable	
A-	--> Black motor cable
B+	--> Red motor cable
B-	--> Blue motor cable

PUL+	--> +5 V
PUL-	--> D5 arduino pin
DIR+	--> +5 V
DIR-	--> D9 arduino pin
ENA+	--> +5 V
ENA-	--> A5 arduino pin

SW1	--> OFF
SW2	--> OFF
SW3	--> ON
SW4	--> OFF
SW5	--> ON
SW6	--> ON
SW7	--> ON
SW8	--> OFF

Stopper switcher:

SW21 (negative direction)
Red cable	--> +5 V
Blue cable	--> GND
Black cable	--> D6

SW22 (positive direction)
Red cable	--> +5 V
Blue cable	--> GND
Black cable	--> D7

For more information please contact us:

Andrii Natochii     andrii.natochii@gmail.com
Leonid Burmistrov   burmist@lal.in2p3.fr 
