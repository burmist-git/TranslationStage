%% MATLAB GUI to control 2D Scanning Device for CORTO experiment
%
% *Author:* Andrii Natochii
% 
% *Email:* andrii.natochii@gmail.com
% 
% UKRAINE , TARAS SHEVCHENKO NATIONAL UNIVERSITY OF KYIV
%
% Master 2
%
% *LAL 2016*
%% Main function TCP_IP_CONNECTION() without arguments
function ScanningDeviceForCORTO()
%% Create GUI elements
% Creating main figure for all other components
f = figure('Visible','off','Name',...
    '2D Scanning Device for CORTO',...
    'Position',[450,200,800,600]);
%% TCP-IP panel
tcp_ip_panel = uipanel('Parent',f,'Title','TPC/IP connection',...
    'FontSize',12,'Position',[0.01 0.8 0.48 0.2]);
% MAC
mac_text = uicontrol(tcp_ip_panel,'Style','text','String',...
    'Device MAC address:','Units','normalized',...
    'Position',[0.0 0.8 0.4 0.2]);
set(mac_text,'FontSize',10);
mac_wind = uicontrol(tcp_ip_panel,'Style','edit','String',...
    '0x00,0x0E,0xF0,0x41,0xE4,0xB1','FontSize',10,'Units','normalized',...
    'BackgroundColor','w','Position',[0.43 0.8 0.56 0.2]);
mac_string = sprintf('Device MAC address');
set(mac_wind,'TooltipString',mac_string);
% IP
ip_text = uicontrol(tcp_ip_panel,'Style','text','String',...
    'Device IP address:','Units','normalized',...
    'Position',[0.0 0.55 0.4 0.2]);
set(ip_text,'FontSize',10);
ip_wind = uicontrol(tcp_ip_panel,'Style','edit','String',...
    '134.158.88.86','FontSize',10,'Units','normalized',...
    'BackgroundColor','w','Position',[0.43 0.55 0.56 0.2]);
ip_string = sprintf('Device IP address');
set(ip_wind,'TooltipString',ip_string);
% Connection Button
connect_button = uicontrol(tcp_ip_panel,'Style','pushbutton',...
    'String','Connect','FontSize',10,'Units','normalized',...
    'Position',[0.01,0.1,0.2,0.3],'BackgroundColor','g',...
    'Callback',{@connectbutton_Callback});
connect_string = sprintf('Press for TCP/IP connection');
set(connect_button,'TooltipString',connect_string);
% Disconnection Button
disconnect_button = uicontrol(tcp_ip_panel,'Style','pushbutton',...
    'String','Disconnect','FontSize',10,'Units','normalized',...
    'Position',[0.22,0.1,0.2,0.3],'BackgroundColor','r',...
    'Callback',{@disconnectbutton_Callback});
disconnect_string = sprintf('Press for TCP/IP disconnection');
set(disconnect_button,'TooltipString',disconnect_string);
% Connection status window
connect_wind = uicontrol(tcp_ip_panel,'Style','edit','String',...
    'Disconnected.','FontSize',10,'Units','normalized',...
    'BackgroundColor','w','Position',[0.43 0.1 0.56 0.3]);
% Connection status
connection = false;
%% Switcher field
% SW11
sw11_button = uicontrol(f,'Style','pushbutton','String','SW11',...
    'Units','normalized','Position',[0.01 0.75 0.06 0.04],...
    'FontSize',10);
set(sw11_button,'BackgroundColor','green');
sw11_string = sprintf('Indicates the status of the Switcher 11');
set(sw11_button,'TooltipString',sw11_string);
% SW12
sw12_button = uicontrol(f,'Style','pushbutton','String','SW12',...
    'Units','normalized','Position',[0.15 0.75 0.06 0.04],...
    'FontSize',10);
set(sw12_button,'BackgroundColor','green');
sw12_string = sprintf('Indicates the status of the Switcher 12');
set(sw12_button,'TooltipString',sw12_string);
% SW21
sw21_button = uicontrol(f,'Style','pushbutton','String','SW21',...
    'Units','normalized','Position',[0.29 0.75 0.06 0.04],...
    'FontSize',10);
set(sw21_button,'BackgroundColor','green');
sw21_string = sprintf('Indicates the status of the Switcher 21');
set(sw21_button,'TooltipString',sw21_string);
% SW22
sw22_button = uicontrol(f,'Style','pushbutton','String','SW22',...
    'Units','normalized','Position',[0.43 0.75 0.06 0.04],...
    'FontSize',10);
set(sw22_button,'BackgroundColor','green');
sw22_string = sprintf('Indicates the status of the Switcher 22');
set(sw22_button,'TooltipString',sw22_string);
%% Motor I panel
% Motor panel with all necessary buttons for motor 1 controlling
motor1panel = uipanel('Parent',f,'Title','Motor I','FontSize',12,...
    'Units','normalized','Position',[0.01 0.55 0.48 0.2]);
% Enabling button
enable1_button = uicontrol(motor1panel,'Style','pushbutton',...
    'String','Enable','Units','normalized','Position',[0.01 0.45 0.2 0.2],...
    'FontSize',10,'Callback',{@enable1button_Callback});
enable1_string = sprintf('Press to Enable Motor I');
set(enable1_button,'TooltipString',enable1_string);
% Disabling button
disable1_button = uicontrol(motor1panel,'Style','pushbutton',...
    'String','Disable','Units','normalized','Position',[0.01 0.65 0.2 0.2],...
    'FontSize',10,'Callback',{@disable1button_Callback});
disable1_string = sprintf('Press to Disable Motor I');
set(disable1_button,'TooltipString',disable1_string);
% Starting Button
start1_button = uicontrol(motor1panel,'Style','pushbutton',...
    'String','Start','Units','normalized','Position',[0.21 0.65 0.2 0.2],...
    'FontSize',10,'Callback',{@start1button_Callback});
start1_string = sprintf('Press to Start moving Motor I');
set(start1_button,'TooltipString',start1_string);
% Stopping Button
stop1_button = uicontrol(motor1panel,'Style','pushbutton',...
    'String','Stop','Units','normalized','Position',[0.21 0.45 0.2 0.2],...
    'FontSize',10,'Callback',{@stop1button_Callback});
stop1_string = sprintf('Press to Stop moving Motor I');
set(stop1_button,'TooltipString',stop1_string);
%
speed1_text = uicontrol(motor1panel,'Style','text','String',...
    'Speed [mm/sec]:','Units','normalized',...
    'Position',[0.41 0.65 0.4 0.16]);
set(speed1_text,'FontSize',10);
% Speed window
speed1_wind = uicontrol(motor1panel,'Style','edit','String','1.0',...
    'FontSize',10,'BackgroundColor','w','Units','normalized',...
    'Position',[0.81 0.65 0.18 0.15]);
speed1_string = sprintf('More than 0.0025 mm/sec \nLess than 10.0 mm/s');
set(speed1_wind,'TooltipString',speed1_string);
%
acc1_text = uicontrol(motor1panel,'Style','text','String',...
    'Acceleration [mm/sec/sec]:','Units','normalized',...
    'Position',[0.41 0.45 0.4 0.16]);
set(acc1_text,'FontSize',10);
% Acceleration window
acc1_wind = uicontrol(motor1panel,'Style','edit','String','0.25',...
    'FontSize',10,'BackgroundColor','w','Units','normalized',...
    'Position',[0.81 0.45 0.18 0.15]);
acc1_string = sprintf('More than 0.0025 mm/sec/sec \nLess than Speed value');
set(acc1_wind,'TooltipString',acc1_string);
% Button for setting current position of the motor
setcurpos1_button = uicontrol(motor1panel,'Style','pushbutton',...
    'String','Set Current Position','Units','normalized',...
    'FontSize',10,'Position',[0.01 0.25 0.4 0.2],...
    'Callback',{@setcurpos1button_Callback});
setcurpos1_string = sprintf('Press for setting motor current position');
set(setcurpos1_button,'TooltipString',setcurpos1_string);
%
curpos1_text = uicontrol(motor1panel,'Style','text','String',...
    'Position [mm]:','Units','normalized',...
    'Position',[0.41 0.25 0.4 0.16]);
set(curpos1_text,'FontSize',10);
% Window for current position value
curpos1_wind = uicontrol(motor1panel,'Style','edit','String','0',...
    'FontSize',10,'BackgroundColor','w','Units','normalized',...
    'Position',[0.81 0.25 0.18 0.15]);
curpos1_string = sprintf('Be sure that position is correct');
set(curpos1_wind,'TooltipString',curpos1_string);
% Button for setting target position of the motor
settargpos1_button = uicontrol(motor1panel,'Style','pushbutton',...
    'String','Set Target Position','Units','normalized',...
    'FontSize',10,'Position',[0.01 0.05 0.4 0.2],...
    'Callback',{@settargpos1button_Callback});
settargpos1_string = sprintf('Press for setting motor target position');
set(settargpos1_button,'TooltipString',settargpos1_string);
%
targ1_text = uicontrol(motor1panel,'Style','text','String',...
    'Position [mm]:','Units','normalized',...
    'Position',[0.41 0.05 0.4 0.16]);
set(targ1_text,'FontSize',10);
% Window for target position value
targpos1_wind = uicontrol(motor1panel,'Style','edit','String','0',...
    'FontSize',10,'BackgroundColor','w','Units','normalized',...
    'Position',[0.81 0.05 0.18 0.15]);
targpos1_string = sprintf('Be sure that position is correct');
set(targpos1_wind,'TooltipString',targpos1_string);
% Value of target position, global variable
targetpos1 = str2double(get(targpos1_wind,'String')); 
% Enabling status
enable1 = false;
% Status of moving and starting
start1 = false;
% Target status
target1 = false;
% Disable all buttons before Press Enable button
set(start1_button,'Enable','off');
set(stop1_button,'Enable','off');
set(disable1_button,'Enable','off');
set(enable1_button,'Enable','on');
set(settargpos1_button,'Enable','off');
set(setcurpos1_button,'Enable','off');
%% Motor II panel
% Motor panel with all necessary buttons for motor 1 controlling
motor2panel = uipanel('Parent',f,'Title','Motor II','FontSize',12,...
    'Units','normalized','Position',[0.01 0.35 0.48 0.2]);
% Enabling button
enable2_button = uicontrol(motor2panel,'Style','pushbutton',...
    'String','Enable','Units','normalized','Position',[0.01 0.45 0.2 0.2],...
    'FontSize',10,'Callback',{@enable2button_Callback});
enable2_string = sprintf('Press to Enable Motor II');
set(enable2_button,'TooltipString',enable2_string);
% Disabling button
disable2_button = uicontrol(motor2panel,'Style','pushbutton',...
    'String','Disable','Units','normalized','Position',[0.01 0.65 0.2 0.2],...
    'FontSize',10,'Callback',{@disable2button_Callback});
disable2_string = sprintf('Press to Disable Motor II');
set(disable2_button,'TooltipString',disable2_string);
% Starting Button
start2_button = uicontrol(motor2panel,'Style','pushbutton',...
    'String','Start','Units','normalized','Position',[0.21 0.65 0.2 0.2],...
    'FontSize',10,'Callback',{@start2button_Callback});
start2_string = sprintf('Press to Start moving Motor II');
set(start2_button,'TooltipString',start2_string);
% Stopping Button
stop2_button = uicontrol(motor2panel,'Style','pushbutton',...
    'String','Stop','Units','normalized','Position',[0.21 0.45 0.2 0.2],...
    'FontSize',10,'Callback',{@stop2button_Callback});
stop2_string = sprintf('Press to Stop moving Motor II');
set(stop2_button,'TooltipString',stop2_string);
% 
speed2_text = uicontrol(motor2panel,'Style','text','String',...
    'Speed [mm/sec]:','Units','normalized',...
    'Position',[0.41 0.65 0.4 0.16]);
set(speed2_text,'FontSize',10);
% Speed window
speed2_wind = uicontrol(motor2panel,'Style','edit','String','1.0',...
    'FontSize',10,'BackgroundColor','w','Units','normalized',...
    'Position',[0.81 0.65 0.18 0.15]);
speed2_string = sprintf('More than 0.0025 mm/sec \nLess than 10.0 mm/s');
set(speed2_wind,'TooltipString',speed2_string);
%
acc2_text = uicontrol(motor2panel,'Style','text','String',...
    'Acceleration [mm/sec/sec]:','Units','normalized',...
    'Position',[0.41 0.45 0.4 0.16]);
set(acc2_text,'FontSize',10);
% Acceleration window
acc2_wind = uicontrol(motor2panel,'Style','edit','String','0.25',...
    'FontSize',10,'BackgroundColor','w','Units','normalized',...
    'Position',[0.81 0.45 0.18 0.15]);
acc2_string = sprintf('More than 0.0025 mm/sec/sec \nLess than Speed value');
set(acc2_wind,'TooltipString',acc2_string);
% Button for setting current position of the motor
setcurpos2_button = uicontrol(motor2panel,'Style','pushbutton',...
    'String','Set Current Position','Units','normalized',...
    'FontSize',10,'Position',[0.01 0.25 0.4 0.2],...
    'Callback',{@setcurpos2button_Callback});
setcurpos2_string = sprintf('Press for setting motor current position');
set(setcurpos2_button,'TooltipString',setcurpos2_string);
%
curpos2_text = uicontrol(motor2panel,'Style','text','String',...
    'Position [mm]:','Units','normalized',...
    'Position',[0.41 0.25 0.4 0.16]);
set(curpos2_text,'FontSize',10);
% Window for current position value
curpos2_wind = uicontrol(motor2panel,'Style','edit','String','0',...
    'FontSize',10,'BackgroundColor','w','Units','normalized',...
    'Position',[0.81 0.25 0.18 0.15]);
curpos2_string = sprintf('Be sure that position is correct');
set(curpos2_wind,'TooltipString',curpos2_string);
% Button for setting target position of the motor
settargpos2_button = uicontrol(motor2panel,'Style','pushbutton',...
    'String','Set Target Position','Units','normalized',...
    'FontSize',10,'Position',[0.01 0.05 0.4 0.2],...
    'Callback',{@settargpos2button_Callback});
settargpos2_string = sprintf('Press for setting motor target position');
set(settargpos2_button,'TooltipString',settargpos2_string);
%
targ2_text = uicontrol(motor2panel,'Style','text','String',...
    'Position [mm]:','Units','normalized',...
    'Position',[0.41 0.05 0.4 0.16]);
set(targ2_text,'FontSize',10);
% Window for target position value
targpos2_wind = uicontrol(motor2panel,'Style','edit','String','0',...
    'FontSize',10,'BackgroundColor','w','Units','normalized',...
    'Position',[0.81 0.05 0.18 0.15]);
targpos2_string = sprintf('Be sure that position is correct');
set(targpos2_wind,'TooltipString',targpos2_string);
% Value of target position, global variable
targetpos2 = str2double(get(targpos2_wind,'String')); 
% Enabling status
enable2 = false;
% Status of moving and starting
start2 = false;
% Target status
target2 = false;
% Disable all buttons before Press Enable button
set(start2_button,'Enable','off');
set(stop2_button,'Enable','off');
set(disable2_button,'Enable','off');
set(enable2_button,'Enable','on');
set(settargpos2_button,'Enable','off');
set(setcurpos2_button,'Enable','off');
%% Log Panel
logpanel = uipanel('Parent',f,'Title','Log window',...
    'FontSize',12,'Units','normalized','Position',[0.01 0.15 0.48 0.2]);
log_wind = uicontrol(logpanel,'Style','list','FontSize',10,...
    'Units','normalized','BackgroundColor','k','ForegroundColor','w',...
    'Position',[0.01 0.01 0.98 0.98]);
set(log_wind,'String',...
    [datestr(now,'mmmm dd, yyyy HH:MM:SS AM') ' :: New session.']);
%% Common STOP button
stop_button = uicontrol(f,'Style','pushbutton','BackgroundColor','r',...
    'String','STOP','Units','normalized','Position',[0.01 0.095 0.48 0.05],...
    'FontSize',10,'Callback',{@stopbutton_Callback});
stop_string = sprintf('Press to stop all motors');
set(stop_button,'TooltipString',stop_string);
%% Draw Panel
drawpanel = uipanel('Parent',f,'Title','Draw Panel','FontSize',12,...
             'Units','normalized','Position',[0.51 0.15 0.48 0.85]);
XYax = axes('Parent',drawpanel);
set(XYax,'Position',[.15 .4 .8 .5]);
xlabel('X_{mm}');
ylabel('Y_{mm}');
% Button for setting trajectory of the motors moving from file
settargposf_button = uicontrol(drawpanel,'Style','pushbutton',...
    'String','Set Target Position From File','Units','normalized','Position',[.1 .2 .4 .1],...
    'Callback',{@settargposfbutton_Callback});
settargposf_string = sprintf('Press for adding the trajectory from file');
set(settargposf_button,'TooltipString',settargposf_string);
% Button for setting current position of the motors moving from file
setcurposf_button = uicontrol(drawpanel,'Style','pushbutton',...
    'String','Set Current Position From File','Units','normalized','Position',[.1 .1 .4 .1],...
    'Callback',{@setcurposfbutton_Callback});
setcurposf_string = sprintf('Press for adding the current position from file');
set(setcurposf_button,'TooltipString',setcurposf_string);
% Start Button for both motors
startf_button = uicontrol(drawpanel,'Style','pushbutton',...
    'String','Start','Units','normalized','Position',[.5 .2 .4 .1],...
    'Callback',{@startfbutton_Callback});
startf_string = sprintf('Press for start moving along the trajectory');
set(startf_button,'TooltipString',startf_string);
% Stop Button for both motors
stopf_button = uicontrol(drawpanel,'Style','pushbutton',...
    'String','Stop','Units','normalized','Position',[.5 .1 .4 .1],...
    'Callback',{@stopfbutton_Callback});
stopf_string = sprintf('Press for stop moving');
set(stopf_button,'TooltipString',stopf_string);
% Window with seconds to stop
pause_wind = uicontrol(drawpanel,'Style','edit','String','0',...
    'FontSize',20,'BackgroundColor','w','Units','normalized',...
    'Position',[.5 .0 .4 .1]);
pause_string = sprintf('How many seconds need to wait at each point');
set(pause_wind,'TooltipString',pause_string);
% Button for creating the trajectory of motors moving
createtr_button = uicontrol(drawpanel,'Style','pushbutton',...
    'String','Create Trajectory','FontSize',10,...
    'Units','normalized','Position',[.1 .0 .4 .1],...
    'Callback',{@createtrbutton_Callback});
createtr_string = sprintf('Press for creating the trajectory');
set(createtr_button,'TooltipString',createtr_string);
%
trajectory = [0 0];     % initial trajectory
targetf = false;        % target status valiable
startf = false;         % start status valiable
ini_num = 1;                  % initial number of the trajectory points
%% Signature
signature_text = uicontrol('Parent',f,'Style','text','String',...
    [datestr(now,'mmmm dd, yyyy HH:MM:SS AM') ' (CORTO LAL)'],'FontAngle','italic',...
    'Units','normalized','Position',[0.01 0.01 0.48 0.04]);
set(signature_text,'FontSize',10);
%% Help button
help_button = uicontrol(f,'Style','pushbutton','String','Help',...
    'Units','normalized','Position',[0.89 0.095 0.1 0.05],...
    'FontSize',10,'Callback',{@helpbutton_Callback});
help_string = sprintf('Press to see the help information');
set(help_button,'TooltipString',help_string);
%% Conversion coefficients
LperR = 3.0;        % [mm/r]
SperR = 1000.0;     % [stp/r]
mm2steps = SperR/LperR;
steps2mm = LperR/SperR;
coef_text = uicontrol(f,'Style','text','String',...
    [num2str(LperR) ' / ' num2str(SperR) ' = ' num2str(steps2mm) '[mm/step]'],...
    'Units','normalized','Position',[0.51 0.095 0.3 0.05],...
    'FontSize',10);
coef_string = sprintf('(Linear/Revolution)/(Steps/Revolution)=(Linear/Step)');
set(coef_text,'TooltipString',coef_string);
%% Get status button
status_button = uicontrol(f,'Style','pushbutton','String','Get Status',...
    'Units','normalized','Position',[0.79 0.095 0.1 0.05],...
    'FontSize',10,'Callback',{@statusbutton_Callback});
status_string = sprintf('Press to see the current system status');
set(status_button,'TooltipString',status_string);
%%
movegui(f,'center');
set(f,'Visible','on');
%% TCPIP obj
% Wait bar
h = waitbar(0,'Please wait...');
steps = 250;
for step = 1:steps
    % computations take place here
    waitbar(step / steps)
end
close(h) 
%Creates a TCPIP object = t, associated with remote host = 80.
t = tcpip(get(ip_wind,'String'), 80);
exist_t = true;
%% Log file obj
% Open file to write the motors position
fid = fopen('logfile.txt', 'a+');
fprintf(fid, '%s :: New session.\n',...
    datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
%% Description of the button functions
%% CONNECT
    function connectbutton_Callback(~,~,~)
        set(connect_wind,'String','Please wait ...');
        pause(1);
        if (exist_t)
            fclose(t);
            delete(t); 
            clear t; 
            exist_t = false;
        end
        %Creates a TCPIP object = t, associated with remote host = 80.
        t = tcpip(get(ip_wind,'String'), 80);
        exist_t = true;
        % Set size of receiving buffer, if needed. 
        set(t, 'InputBufferSize', 30000);
        % Time for scanning the ethernet port 100 mks
        set(t, 'timeout', 0.1);
        % Open connection to the server.
        fopen(t);
        
        if(isvalid(t))
            connection = true;
            set(connect_wind,'String','Connected.');
            set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                ' :: Connected to ' get(ip_wind, 'String')]}));
            fprintf(fid, '%s :: Connected to %s\n',...
                datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),...
                get(ip_wind, 'String'));
        else
            connection = false;
            set(connect_wind,'String','Disconnected.');
            errordlg(['Cannot connect to ' get(ip_wind, 'String')],...
                'Connection error');
            set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                ' :: Connection error.']}));
            fprintf(fid, '%s :: Connection error.\n',...
                datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
        end
    end
%% DISCONNECT
    function disconnectbutton_Callback(~,~,~)
        fclose(t);
        delete(t); 
        clear t;
        exist_t = false;
        connection = false;
        set(connect_wind,'String','Disconnected.');
        set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
            {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
            ' :: Disconnected.']}));
        fprintf(fid, '%s :: Disconnected.\n',...
            datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));        
    end
%% ENABLE BUTTON (MOTOR I)
    function enable1button_Callback(~,~,~)
        if(connection)
            fprintf(t, '?e1');
            enable1 = true;
            set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                ' :: Enable Motor I.']}));
            fprintf(fid, '%s :: Enable Motor I.\n',...
                datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
            
            set(start1_button,'Enable','on');
            set(stop1_button,'Enable','on');
            set(disable1_button,'Enable','on');
            set(enable1_button,'Enable','off');
            set(settargpos1_button,'Enable','on');
            set(setcurpos1_button,'Enable','on');            
        else
            errordlg('Connect, please!','Connection error');
        end
    end
%% DISABLE BUTTON (MOTOR I)
    function disable1button_Callback(~,~,~)
        if(connection)
            fprintf(t, '?de1');
            enable1 = false;
            set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                ' :: Disable Motor I.']}));
            fprintf(fid, '%s :: Disable Motor I.\n',...
                datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
            
            set(start1_button,'Enable','off');
            set(stop1_button,'Enable','off');
            set(disable1_button,'Enable','off');
            set(enable1_button,'Enable','on');
            set(settargpos1_button,'Enable','off');
            set(setcurpos1_button,'Enable','off');
        else
            errordlg('Connect, please!','Connection error');
        end
    end
%% START BUTTON (MOTOR I)
    function start1button_Callback(~,~,~)
        if(connection && enable1 && target1 && ~start1 && ~start2 && ~startf && ~targetf)
            set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                ' :: Motor I has started to move.']}));
            fprintf(fid, '%s :: Motor I has started to move.\n',...
                datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
            
            start1 = true;
            speed = str2double(get(speed1_wind,'String'))*mm2steps;
            accel = str2double(get(acc1_wind,'String'))*mm2steps;
            
            if speed < 1.0
                speed = 1;
            elseif speed > 3333.3
                speed = 3333.3;
            end
            if accel < 1.0
                accel = 1;
            elseif accel > speed
                accel = speed;
            end
            
            fprintf(t,['?m1sp' num2str(int64(speed))]);
            fprintf(t,['?m1ac' num2str(int64(accel))]);
            
            set(speed1_wind,'String',speed*steps2mm);
            set(acc1_wind,'String',accel*steps2mm);
            
            if targetpos1 < 0
                fprintf(t,'?nd1');
            else
                fprintf(t,'?d1');
            end
            
            fprintf(t,['?m1move' num2str(int64(abs(targetpos1)))]);
            
            x0 = str2double(get(curpos1_wind,'String'))*mm2steps;
            distanceToGo1 = abs(targetpos1 - x0);      

            cla(XYax,'reset');                
            line([x0*steps2mm targetpos1*steps2mm],[0 0],'Parent',XYax,...
                'Color','r','Marker','o','LineStyle',':');
            xlabel('X_{mm}');
            ylabel('Y_{mm}');
            
            while abs(distanceToGo1) > 0
                pause(0.1)
                drawnow;
                if ~start1
                    break;
                end
                % SW11 status
                fprintf(t,'?sw11');
                pause(0.1);
                sw11st = '';
                while (get(t, 'BytesAvailable') > 0)
                    sw11st = fscanf(t);
                end
                if str2double(sw11st) == 0
                    set(sw11_button,'BackgroundColor','red');
                    start1 = false;
                    break;
                else
                    set(sw11_button,'BackgroundColor','green');
                end
                % SW12 status
                fprintf(t,'?sw12');
                pause(0.1);
                sw12st = '';
                while (get(t, 'BytesAvailable') > 0)
                    sw12st = fscanf(t);
                end
                if str2double(sw12st) == 0
                    set(sw12_button,'BackgroundColor','red');
                    start1 = false;
                    break;
                else
                    set(sw12_button,'BackgroundColor','green');
                end                
                
                fprintf(t,'?b');
                pause(0.5);
                inputchar = '';
                while (get(t, 'BytesAvailable') > 0)
                    inputchar = fscanf(t);
                end
                
                distanceToGo1 = str2double(inputchar);
                if start1                    
                    x = x0 + ((targetpos1 - x0)/abs(targetpos1 ...
                        - x0))*(abs(targetpos1 - x0) - abs(distanceToGo1));   
                    line(x*steps2mm,0,'Parent',XYax,'Color','b',...
                        'Marker','+','LineStyle','-');
                    xlabel('X_{mm}');
                    ylabel('Y_{mm}');
                    hold on;
                    set(curpos1_wind,'String',num2str(x*steps2mm));

                    set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                        {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                        ' :: PosMotI = ' num2str(x*steps2mm) ' mm.']}));
                    fprintf(fid, '%s :: PosMotI = %12.12f mm.\n',...
                        datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),x*steps2mm);
                end
                
                if abs(distanceToGo1) == 0
                    start1 = false;                
                end                              
            end
            start1 = false;                      
        else
            errordlg('ERROR, wrong Connection or Enabling or Target position!!!','Error');
        end
        set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
            {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
            ' :: Motor I has been stopped.']}));
        fprintf(fid, '%s :: Motor I has been stopped.\n',...
            datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
    end
%% STOP BUTTON (MOTOR I)
    function stop1button_Callback(~,~,~)
        start1 = false;        
        fprintf(t,'?m1stop');
        drawnow; 
        set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
            {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
            ' :: Motor I has been stopped.']}));
        fprintf(fid, '%s :: Motor I has been stopped.\n',...
            datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
    end
%% SET CURRENT POSITION BUTTON (MOTOR I)
    function setcurpos1button_Callback(~,~,~)
        if(connection)
            clear choice;
            choice = questdlg('In which way?','Attention!','Manually', ...
                'From LOG file','Cancel','Cancel');
            switch choice
                case 'Manually'
                    clear curpos1;
                    curpos1 = str2double(get(curpos1_wind,'String'))*mm2steps;
                    if curpos1 < 0
                        fprintf(t, ['?m1cpm' num2str(int64(abs(curpos1)))]);
                    else
                        fprintf(t, ['?m1cpp' num2str(int64(curpos1))]);
                    end                    
                    set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                        {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                        ' :: Added current position for Motor I is '...
                        get(curpos1_wind,'String') ' mm.']}));
                    fprintf(fid,...
                        '%s :: Added current position for Motor I is %s mm.\n',...
                        datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),...
                        get(curpos1_wind,'String'));                                                     
                case 'From LOG file'
                    clear fileID filename pathname;
                    [filename, pathname] = uigetfile({'*.txt';'*.dat';'*.*'},...
                        'File Selector','logfile.txt');
                    fileID = fopen([pathname filename],'r');        
                    XYc1 = textscan(fileID,'%s');
                    fclose(fileID);
                    XYc2 = cellstr(XYc1{1});
                    clear XYc1;
                    SizeOfXYc2 = size(XYc2,1);
                    ii = 1;
                    h = waitbar(0,'Please wait...');
                    while ii <= SizeOfXYc2
                        if strcmp(XYc2(ii),'PosMotI') && strcmp(XYc2(ii+1),'=')
                            set(curpos1_wind,'String',char(XYc2(ii+2)));
                            ii = ii + 2;
                        end
                        waitbar(ii / SizeOfXYc2)
                        ii = ii + 1;
                    end
                    curpos1 = str2double(get(curpos1_wind,'String'))*mm2steps;
                    if curpos1 < 0
                        fprintf(t, ['?m1cpm' num2str(int64(abs(curpos1)))]);
                    else
                        fprintf(t, ['?m1cpp' num2str(int64(curpos1))]);
                    end
                    set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                        {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                        ' :: Added current position for Motor I is '...
                        get(curpos1_wind,'String') ' mm.']}));
                    fprintf(fid,...
                        '%s :: Added current position for Motor I is %s mm.\n',...
                        datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),...
                        get(curpos1_wind,'String'));                                     
                    close(h);
                    msgbox('Done!');
                case 'Cancel'
            end
        else
            errordlg('Connect, please!','Connection error');
        end
    end
%% SET TARGET POSITION BUTTON (MOTOR I)
    function settargpos1button_Callback(~,~,~)
        if(connection)
            clear choice;
            choice = questdlg('Are you sure?','Attention!','Yes', ...
                'No','No');
            switch choice
                case 'Yes'
                    clear targetpos1;
                    targetpos1 = str2double(get(targpos1_wind,'String'));
                    line([str2double(get(curpos1_wind,'String')) targetpos1],...
                        [0 0],'Parent',XYax,'Color','r','Marker','o','LineStyle',':');
                    xlabel('X_{mm}');
                    ylabel('Y_{mm}');
                    targetpos1 = targetpos1*mm2steps;
                    target1 = true;
                    targetf = false;
                    set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                        {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                        ' :: Added target position for Motor I is '...
                        get(targpos1_wind,'String') ' mm.']}));
                    fprintf(fid,...
                        '%s :: Added target position for Motor I is %s mm.\n',...
                        datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),...
                        get(targpos1_wind,'String'));
                case 'No'
            end            
        else
            errordlg('Connect, please!','Connection error');
        end
    end
%% ENABLE BUTTON (MOTOR II)
    function enable2button_Callback(~,~,~)
        if(connection)
            fprintf(t, '?e2');
            enable2 = true;
            set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                ' :: Enable Motor II.']}));
            fprintf(fid, '%s :: Enable Motor II.\n',...
                datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
            
            set(start2_button,'Enable','on');
            set(stop2_button,'Enable','on');
            set(disable2_button,'Enable','on');
            set(enable2_button,'Enable','off');
            set(settargpos2_button,'Enable','on');
            set(setcurpos2_button,'Enable','on');
        else
            errordlg('Connect, please!','Connection error');
        end
    end
%% DISABLE BUTTON (MOTOR II)
    function disable2button_Callback(~,~,~)
        if(connection)
            fprintf(t, '?de2');
            enable2 = false;
            set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                ' :: Disable Motor II.']}));
            fprintf(fid, '%s :: Disable Motor II.\n',...
                datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
            
            set(start2_button,'Enable','off');
            set(stop2_button,'Enable','off');
            set(disable2_button,'Enable','off');
            set(enable2_button,'Enable','on');
            set(settargpos2_button,'Enable','off');
            set(setcurpos2_button,'Enable','off');
        else
            errordlg('Connect, please!','Connection error');
        end
    end
%% START BUTTON (MOTOR II)
    function start2button_Callback(~,~,~)
        if(connection && enable2 && target2 && ~start2 && ~start1 && ~startf && ~targetf)
            set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                ' :: Motor II has started to move.']}));
            fprintf(fid, '%s :: Motor II has started to move.\n',...
                datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
            
            start2 = true;
            speed = str2double(get(speed2_wind,'String'))*mm2steps;
            accel = str2double(get(acc2_wind,'String'))*mm2steps;
            
            if speed < 1.0
                speed = 1;
            elseif speed > 3333.3
                speed = 3333.3;
            end
            if accel < 1.0
                accel = 1;
            elseif accel > speed
                accel = speed;
            end
            
            fprintf(t,['?m2sp' num2str(int64(speed))]);
            fprintf(t,['?m2ac' num2str(int64(accel))]);
            
            set(speed2_wind,'String',speed*steps2mm);
            set(acc2_wind,'String',accel*steps2mm);
            
            if targetpos2 < 0
                fprintf(t,'?nd2');
            else
                fprintf(t,'?d2');
            end
            
            fprintf(t,['?m2move' num2str(int64(abs(targetpos2)))]);
            
            x0 = str2double(get(curpos2_wind,'String'))*mm2steps;
            distanceToGo2 = abs(targetpos2 - x0);      
            
            cla(XYax,'reset');                
            line([x0*steps2mm targetpos2*steps2mm],[0 0],'Parent',XYax,...
                'Color','r','Marker','o','LineStyle',':');
            xlabel('X_{mm}');
            ylabel('Y_{mm}');
            
            while abs(distanceToGo2) > 0
                pause(0.1)
                drawnow;
                if ~start2
                    break;
                end
              
                % SW21 status
                fprintf(t,'?sw21');
                pause(0.1);
                sw21st = '';
                while (get(t, 'BytesAvailable') > 0)
                    sw21st = fscanf(t);
                end
                if str2double(sw21st) == 0
                    set(sw21_button,'BackgroundColor','red');
                    start2 = false;
                    break;
                else
                    set(sw21_button,'BackgroundColor','green');
                end
                % SW22 status
                fprintf(t,'?sw22');
                pause(0.1);
                sw22st = '';
                while (get(t, 'BytesAvailable') > 0)
                    sw22st = fscanf(t);
                end
                if str2double(sw22st) == 0
                    set(sw22_button,'BackgroundColor','red');
                    start2 = false;
                    break;
                else
                    set(sw22_button,'BackgroundColor','green');
                end   
                
                fprintf(t,'?u');
                pause(0.5);
                inputchar = '';
                while (get(t, 'BytesAvailable') > 0)
                    inputchar = fscanf(t);
                end
                
                distanceToGo2 = str2double(inputchar);    
                
                if start2
                    x = x0 + ((targetpos2 - x0)/abs(targetpos2 ...
                        - x0))*(abs(targetpos2 - x0) - abs(distanceToGo2));                
                    line(x*steps2mm,0,'Parent',XYax,'Color','b',...
                        'Marker','+','LineStyle','-');
                    xlabel('X_{mm}');
                    ylabel('Y_{mm}');
                    hold on;
                    set(curpos2_wind,'String',num2str(x*steps2mm));

                    set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                        {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                        ' :: PosMotII = ' num2str(x*steps2mm) ' mm.']}));
                    fprintf(fid, '%s :: PosMotII = %12.12f mm.\n',...
                        datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),x*steps2mm);
                end
                
                if abs(distanceToGo2) == 0
                    start2 = false;                
                end                             
            end
            start2 = false;            
        else
            errordlg('ERROR, wrong Connection or Enabling or Target position!!!','Error');
        end
        set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
            {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
            ' :: Motor II has been stopped.']}));
        fprintf(fid, '%s :: Motor II has been stopped.\n',...
            datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
    end
%% STOP BUTTON (MOTOR II)
    function stop2button_Callback(~,~,~)
        start2 = false;        
        fprintf(t,'?m2stop');   
        drawnow; 
        set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
            {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
            ' :: Motor II has been stopped.']}));
        fprintf(fid, '%s :: Motor II has been stopped.\n',...
            datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
    end
%% SET CURRENT POSITION BUTTON (MOTOR II)
    function setcurpos2button_Callback(~,~,~)
        if(connection)
            clear choice;
            choice = questdlg('In which way?','Attention!','Manually', ...
                'From LOG file','Cancel','Cancel');
            switch choice
                case 'Manually'
                    clear curpos2;
                    curpos2 = str2double(get(curpos2_wind,'String'))*mm2steps;
                    
                    if curpos2 < 0
                        fprintf(t, ['?m2cpm' num2str(int64(abs(curpos2)))]);
                    else
                        fprintf(t, ['?m2cpp' num2str(int64(curpos2))]);
                    end                    
                    set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                        {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                        ' :: Added current position for Motor II is '...
                        get(curpos2_wind,'String') ' mm.']}));
                    fprintf(fid,...
                        '%s :: Added current position for Motor II is %s mm.\n',...
                        datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),...
                        get(curpos2_wind,'String'));                                                     
                case 'From LOG file'
                    clear fileID filename pathname;
                    [filename, pathname] = uigetfile({'*.txt';'*.dat';'*.*'},...
                        'File Selector','logfile.txt');
                    fileID = fopen([pathname filename],'r');        
                    XYc1 = textscan(fileID,'%s');
                    fclose(fileID);
                    XYc2 = cellstr(XYc1{1});
                    clear XYc1;
                    SizeOfXYc2 = size(XYc2,1);
                    ii = 1;
                    h = waitbar(0,'Please wait...');
                    while ii <= SizeOfXYc2
                        if strcmp(XYc2(ii),'PosMotII') && strcmp(XYc2(ii+1),'=')
                            set(curpos2_wind,'String',char(XYc2(ii+2)));
                            ii = ii + 2;
                        end
                        waitbar(ii / SizeOfXYc2)
                        ii = ii + 1;
                    end
                    curpos2 = str2double(get(curpos2_wind,'String'))*mm2steps;
                    if curpos2 < 0
                        fprintf(t, ['?m2cpm' num2str(int64(abs(curpos2)))]);
                    else
                        fprintf(t, ['?m2cpp' num2str(int64(curpos2))]);
                    end
                    set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                        {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                        ' :: Added current position for Motor II is '...
                        get(curpos2_wind,'String') ' mm.']}));
                    fprintf(fid,...
                        '%s :: Added current position for Motor II is %s mm.\n',...
                        datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),...
                        get(curpos2_wind,'String'));                                     
                    close(h);
                    msgbox('Done!');
                case 'Cancel'
            end
        else
            errordlg('Connect, please!','Connection error');
        end
    end
%% SET TARGET POSITION BUTTON (MOTOR II)
    function settargpos2button_Callback(~,~,~)
        if(connection)
            clear choice;
            choice = questdlg('Are you sure?','Attention!','Yes', ...
                'No','No');
            switch choice
                case 'Yes'
                    clear targetpos2;
                    targetpos2 = str2double(get(targpos2_wind,'String'));
                    line([str2double(get(curpos2_wind,'String')) targetpos2],...
                        [0 0],'Parent',XYax,'Color','r','Marker','o','LineStyle',':');
                    xlabel('X_{mm}');
                    ylabel('Y_{mm}');
                    targetpos2 = targetpos2*mm2steps;
                    target2 = true;
                    targetf = false;
                    set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                        {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                        ' :: Added target position for Motor II is '...
                        get(targpos2_wind,'String') ' mm.']}));
                    fprintf(fid,...
                        '%s :: Added target position for Motor II is %s mm.\n',...
                        datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),...
                        get(targpos2_wind,'String'));
                case 'No'
            end            
        else
            errordlg('Connect, please!','Connection error');
        end
    end
%% COMMON STOP BUTTON
    function stopbutton_Callback(~,~,~)
        start1 = false;
        start2 = false;
        fprintf(t,'?m1stop');
        pause(0.01);
        fprintf(t,'?m2stop');
        drawnow;
        set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
            {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
            ' :: Motor I & Motor II have been stopped.']}));
        fprintf(fid, '%s :: Motor I & Motor II have been stopped.\n',...
            datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
    end
%% HELP BUTTON
    function helpbutton_Callback(~,~,~) 
        helpfig = figure('Visible','off','Name',...
            'Help window','Position',[450,200,400,300]);
        help_wind = uicontrol('Parent',helpfig,'Style','list','FontSize',10,...
            'Units','normalized','BackgroundColor','w','ForegroundColor','k',...
            'Position',[0.01 0.01 0.98 0.98]);
        movegui(helpfig,'center');
        set([helpfig,help_wind],'Units','normalized');
        set(helpfig,'Visible','on');
        
        clear fileID;
        fileID = fopen('readme.txt','r');
        tline = fgetl(fileID);
        while ischar(tline)
            set(help_wind, 'String', cat(1, get(help_wind, 'String'),{tline}));
            tline = fgetl(fileID);
        end        
        fclose(fileID);
    end
%% GET STATUS BUTTON
    function statusbutton_Callback(~,~,~)
        if(connection)
            h = waitbar(0,'Please wait...');
            stps = 1000;
            for st = 1:stps
                waitbar(st / stps)
            end
            close(h)
            
            fprintf(t,'?gcp1');
            pause(0.5);
            inputchar='';
            while (get(t, 'BytesAvailable') > 0)
                inputchar = fscanf(t);
            end
            x = str2double(inputchar);
            set(curpos1_wind,'String',num2str(x*steps2mm));
            
            fprintf(t,'?gcp2');
            pause(0.5);
            inputchar='';
            while (get(t, 'BytesAvailable') > 0)
                inputchar = fscanf(t);
            end
            x = str2double(inputchar);
            set(curpos2_wind,'String',num2str(x*steps2mm));
            
            fprintf(t,'?mst');
            pause(0.5);
            inputchar='';
            while (get(t, 'BytesAvailable') > 0)
                inputchar = fscanf(t);
            end
            set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                ' :: ' inputchar]}));
            
            fprintf(fid, '%s :: %s.\n',...
                datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),inputchar);
            % SW11 status
            fprintf(t,'?sw11');
            pause(0.1);
            sw11st = '';
            while (get(t, 'BytesAvailable') > 0)
                sw11st = fscanf(t);
            end
            if str2double(sw11st) == 0
                set(sw11_button,'BackgroundColor','red');
            else
                set(sw11_button,'BackgroundColor','green');
            end
            % SW12 status
            fprintf(t,'?sw12');
            pause(0.1);
            sw12st = '';
            while (get(t, 'BytesAvailable') > 0)
                sw12st = fscanf(t);
            end
            if str2double(sw12st) == 0
                set(sw12_button,'BackgroundColor','red');
            else
                set(sw12_button,'BackgroundColor','green');
            end
            % SW21 status
            fprintf(t,'?sw21');
            pause(0.1);
            sw21st = '';
            while (get(t, 'BytesAvailable') > 0)
                sw21st = fscanf(t);
            end
            if str2double(sw21st) == 0
                set(sw21_button,'BackgroundColor','red');
            else
                set(sw21_button,'BackgroundColor','green');
            end
            % SW22 status
            fprintf(t,'?sw22');
            pause(0.1);
            sw22st = '';
            while (get(t, 'BytesAvailable') > 0)
                sw22st = fscanf(t);
            end
            if str2double(sw22st) == 0
                set(sw22_button,'BackgroundColor','red');
            else
                set(sw22_button,'BackgroundColor','green');
            end
        else
            errordlg('Connect, please!','Connection error');
        end
    end
%% CREATE TRAJECTORY
    function createtrbutton_Callback(~,~,~)
       create_coord();
    end
%% SET TARGET POSITION FROM FILE
    function settargposfbutton_Callback(~,~,~)
        clear fileID trajectory counts;
        [filename, pathname] = uigetfile({'*.txt';'*.mat';'*.dat';'*.*'},'File Selector');
        fileID = fopen([pathname filename],'r');        
        [trajectory,counts] = fscanf(fileID,'%f %f',[2 Inf]);
        if counts <= 0
            errordlg(['ERROR: file ' pathname filename ' is empty!'],'Input file error.');
            targetf = false;
        else
            ini_num = 1;
            target1 = false;
            target2 = false;
            targetf = true;
        end
        fclose(fileID);
        cla(XYax,'reset');        
        line(trajectory(1,:),trajectory(2,:),'Parent',XYax,'Color','b','Marker','o','LineStyle',':');
        xlabel('X_{mm}');
        ylabel('Y_{mm}');
        trajectory(1,:) = trajectory(1,:).*mm2steps;
        trajectory(2,:) = trajectory(2,:).*mm2steps;
        hold on;
    end
%% SET CURRENT POSITION FROM FILE
    function setcurposfbutton_Callback(~,~,~)
        clear fileID filename pathname;
        [filename, pathname] = uigetfile({'*.txt';'*.dat';'*.*'},...
            'File Selector','logfile.txt');
        fileID = fopen([pathname filename],'r');        
        XYc1 = textscan(fileID,'%s');
        fclose(fileID);
        XYc2 = cellstr(XYc1{1});
        clear XYc1;
        SizeOfXYc2 = size(XYc2,1);
        ii = 1;
        h = waitbar(0,'Please wait...');
        while ii <= SizeOfXYc2
            if strcmp(XYc2(ii),'PosMotI') && strcmp(XYc2(ii+1),'=')
                set(curpos1_wind,'String',char(XYc2(ii+2)));
                ii = ii + 2;
            end
            if strcmp(XYc2(ii),'PosMotII') && strcmp(XYc2(ii+1),'=')
                set(curpos2_wind,'String',char(XYc2(ii+2)));
                ii = ii + 2;
            end
            waitbar(ii / SizeOfXYc2)
            ii = ii + 1;
        end
        curpos1 = str2double(get(curpos1_wind,'String'))*mm2steps;
        curpos2 = str2double(get(curpos2_wind,'String'))*mm2steps;
        if curpos1 < 0
            fprintf(t, ['?m1cpm' num2str(int64(abs(curpos1)))]);
        else
            fprintf(t, ['?m1cpp' num2str(int64(curpos1))]);
        end
        if curpos2 < 0
            fprintf(t, ['?m2cpm' num2str(int64(abs(curpos2)))]);
        else
            fprintf(t, ['?m2cpp' num2str(int64(curpos2))]);
        end
        set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
            {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
            ' :: Added current position for Motor I is '...
            get(curpos1_wind,'String') ' mm.']}));
        set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
            {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
            ' :: Added current position for Motor II is '...
            get(curpos2_wind,'String') ' mm.']}));
        
        fprintf(fid,...
            '%s :: Added current position for Motor I is %s mm.\n',...
            datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),...
            get(curpos1_wind,'String')); 
        fprintf(fid,...
            '%s :: Added current position for Motor II is %s mm.\n',...
            datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),...
            get(curpos2_wind,'String'));                                     
        close(h);
        msgbox('Done!');        
    end
%% START MOTORs
    function startfbutton_Callback(~,~,~)
        if(connection && enable1 && enable2 && ~target1 && ~target2 && targetf && ~start1 && ~start2 && ~startf)
            startf = true;
            cla(XYax,'reset');            
            line(trajectory(1,:)*steps2mm,trajectory(2,:)*steps2mm,...
                'Parent',XYax,'Color','r','Marker','o','LineStyle',':');
            xlabel('X_{mm}');
            ylabel('Y_{mm}');
            
            x0 = str2double(get(curpos1_wind,'String'))*mm2steps;
            y0 = str2double(get(curpos2_wind,'String'))*mm2steps;            
            
            Vx = str2double(get(speed1_wind,'String'))*mm2steps;
            Ax = str2double(get(acc1_wind,'String'))*mm2steps;
            Vy = str2double(get(speed2_wind,'String'))*mm2steps;
            Ay = str2double(get(acc2_wind,'String'))*mm2steps;
            
            if Vx < 1.0
                Vx = 1.0;
            elseif Vx > 3333.3
                Vx = 3333.3;
            end
            if Ax < 1.0
                Ax = 1.0;
            elseif Ax > Vx
                Ax = Vx;
            end
            
            if Vy < 1.0
                Vy = 1.0;
            elseif Vy > 3333.3
                Vy = 3333.3;
            end
            if Ay < 1.0
                Ay = 1.0;
            elseif Ay > Vy
                Ay = Vy;
            end
            fprintf(t,['?m1sp' num2str(int64(Vx))]);
            fprintf(t,['?m2sp' num2str(int64(Vy))]);
            fprintf(t,['?m1ac' num2str(int64(Ax))]);
            fprintf(t,['?m2ac' num2str(int64(Ay))]);
            
            set(speed1_wind,'String',Vx*steps2mm);
            set(acc1_wind,'String',Ax*steps2mm);
            set(speed2_wind,'String',Vy*steps2mm);
            set(acc2_wind,'String',Ay*steps2mm);
            
            pauseTime = abs(str2double(get(pause_wind,'String')));
            
            while ini_num <= size(trajectory(1,:),2)
                if ~startf
                    break;
                end               
                
                distanceToGo1 = abs(trajectory(1,ini_num) - x0);
                distanceToGo2 = abs(trajectory(2,ini_num) - y0);
                if trajectory(1,ini_num) < 0
                    fprintf(t,'?nd1');
                    pause(1);
                else
                    fprintf(t,'?d1');
                    pause(1);
                end
                if trajectory(2,ini_num) < 0
                    fprintf(t,'?nd2');
                    pause(1);
                else
                    fprintf(t,'?d2');
                    pause(1);
                end

                fprintf(t,['?m1move' num2str(int64(abs(trajectory(1,ini_num))))]);
                pause(0.5);
                fprintf(t,['?m2move' num2str(int64(abs(trajectory(2,ini_num))))]);
                pause(0.5);
                
                while abs(distanceToGo1) > 0 || abs(distanceToGo2) > 0
                    pause(0.1)
                    drawnow;
                    if ~startf                        
                        break;
                    end
                    
                    % SW11 status
                    fprintf(t,'?sw11');
                    pause(0.1);
                    sw11st = '';
                    while (get(t, 'BytesAvailable') > 0)
                        sw11st = fscanf(t);
                    end
                    if str2double(sw11st) == 0
                        set(sw11_button,'BackgroundColor','red');
                        startf = false;
                        break;
                    else
                        set(sw11_button,'BackgroundColor','green');
                    end
                    % SW12 status
                    fprintf(t,'?sw12');
                    pause(0.1);
                    sw12st = '';
                    while (get(t, 'BytesAvailable') > 0)
                        sw12st = fscanf(t);
                    end
                    if str2double(sw12st) == 0
                        set(sw12_button,'BackgroundColor','red');
                        startf = false;
                        break;
                    else
                        set(sw12_button,'BackgroundColor','green');
                    end
                    % SW21 status
                    fprintf(t,'?sw21');
                    pause(0.1);
                    sw21st = '';
                    while (get(t, 'BytesAvailable') > 0)
                        sw21st = fscanf(t);
                    end
                    if str2double(sw21st) == 0
                        set(sw21_button,'BackgroundColor','red');
                        startf = false;
                        break;
                    else
                        set(sw21_button,'BackgroundColor','green');
                    end
                    % SW22 status
                    fprintf(t,'?sw22');
                    pause(0.1);
                    sw22st = '';
                    while (get(t, 'BytesAvailable') > 0)
                        sw22st = fscanf(t);
                    end
                    if str2double(sw22st) == 0
                        set(sw22_button,'BackgroundColor','red');
                        startf = false;
                        break;
                    else
                        set(sw22_button,'BackgroundColor','green');
                    end

                    fprintf(t,'?b');
                    pause(0.1);
                    while (get(t, 'BytesAvailable') > 0)
                        inputchar = fscanf(t);
                    end
                    distanceToGo1 = str2double(inputchar);

                    fprintf(t,'?u');
                    pause(0.1);
                    while (get(t, 'BytesAvailable') > 0)                        
                        inputchar = fscanf(t);
                    end                
                    distanceToGo2 = str2double(inputchar);

                    if startf
                        x = x0+((trajectory(1,ini_num) - x0)/abs(trajectory(1,ini_num) ...
                            - x0))*(abs(trajectory(1,ini_num) - x0) - abs(distanceToGo1));
                        y = y0+((trajectory(2,ini_num) - y0)/abs(trajectory(2,ini_num) ...
                            - y0))*(abs(trajectory(2,ini_num) - y0) - abs(distanceToGo2));                   
                        line(x*steps2mm,y*steps2mm,'Parent',XYax,'Color','b','Marker','.','LineStyle','-');
                        xlabel('X_{mm}');
                        ylabel('Y_{mm}');
                        hold on;
                        set(curpos1_wind,'String',num2str(int64(x*steps2mm)));
                        set(curpos2_wind,'String',num2str(int64(y*steps2mm)));

                        set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                            {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                            ' :: PosMotI = ' num2str(x*steps2mm) ' mm.']}));
                        fprintf(fid, '%s :: PosMotI = %12.12f mm.\n',...
                            datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),x*steps2mm);
                        set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                            {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                            ' :: PosMotII = ' num2str(y*steps2mm) ' mm.']}));
                        fprintf(fid, '%s :: PosMotII = %12.12f mm.\n',...
                            datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),y*steps2mm);
                    end
                end
                if startf
                    x0 = trajectory(1,ini_num);
                    y0 = trajectory(2,ini_num);
                    ini_num = ini_num + 1;

                    if ~startf
                        break;
                    end
                    pTst = false;
                    if pauseTime > 600
                        fprintf(t, '?de1');
                        enable1 = false;
                        pause(0.1);
                        fprintf(t, '?de2');
                        enable2 = false;
                        pause(0.1);
                        pTst = true;
                    end
                    hh = waitbar(0,['Please wait ' num2str(pauseTime) ' seconds at this point.']);
                    tic;
                    tocv = toc;
                    while tocv <= pauseTime
                        waitbar(tocv/pauseTime)
                        tocv = toc;
                        if ~startf
                            break;
                        end
                    end
                    close(hh)
                    clear hh;
                    if ~startf
                        break;
                    end
                    if pTst
                        fprintf(t, '?e1');
                        enable1 = true;
                        pause(0.1);
                        fprintf(t, '?e2');
                        enable2 = true;
                        pause(0.1);
                    end
                end
                hold on;
            end
        else
            errordlg('ERROR, wrong Connection or Enabling or Target position!!!','Error');            
        end
        startf = false;        
        set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
            {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
            ' :: Motor I & Motor II have been stopped.']}));
        fprintf(fid, '%s :: Motor I & Motor II have been stopped.\n',...
            datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
    end
%% STOP MOTORs
    function stopfbutton_Callback(~,~,~)
        startf = false;
        fprintf(t,'?m1stop');
        fprintf(t,'?m2stop');
        set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
            {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
            ' :: Motor I & Motor II have been stopped.']}));
        fprintf(fid, '%s :: Motor I & Motor II have been stopped.\n',...
            datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
    end
end
%%