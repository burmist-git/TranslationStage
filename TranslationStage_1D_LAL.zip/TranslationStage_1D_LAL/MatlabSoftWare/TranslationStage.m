%% MATLAB GUI to control 1D Translation Stage
%
% *Author:* Andrii Natochii
% 
% *Email:* natochii@lal.in2p3.fr
% 
% FRANCE , Paris Saclay University
%
% Ph.D.
%
% *LAL 2016*
%% Main function TCP_IP_CONNECTION() without arguments
function TranslationStage()
%% Create GUI elements
% Creating main figure for all other components
f = figure('Visible','off','Name',...
    '1D Translation Stage',...
    'Position',[450,200,1200,800]);
%% TCP-IP panel
tcp_ip_panel = uipanel('Parent',f,'Title','TPC/IP connection',...
    'FontSize',12,'Position',[0.01 0.8 0.48 0.2]);
% MAC
mac_text = uicontrol(tcp_ip_panel,'Style','text','String',...
    'Device MAC address:','Units','normalized',...
    'Position',[0.0 0.8 0.4 0.2]);
set(mac_text,'FontSize',10);
mac_wind = uicontrol(tcp_ip_panel,'Style','edit','String',...
    '0x90,0xA2,0xDA,0x10,0x76,0xFE','FontSize',10,'Units','normalized',...
    'BackgroundColor','w','Position',[0.43 0.8 0.56 0.2]);
mac_string = sprintf('Device MAC address');
set(mac_wind,'TooltipString',mac_string);
% IP
ip_text = uicontrol(tcp_ip_panel,'Style','text','String',...
    'Device IP address:','Units','normalized',...
    'Position',[0.0 0.55 0.4 0.2]);
set(ip_text,'FontSize',10);
ip_wind = uicontrol(tcp_ip_panel,'Style','edit','String',...
    '134.158.76.35','FontSize',10,'Units','normalized',...
    'BackgroundColor','w','Position',[0.43 0.55 0.56 0.2]);
ip_string = sprintf('Device IP address');
set(ip_wind,'TooltipString',ip_string);
% Connection Button
connect_button = uicontrol(tcp_ip_panel,'Style','pushbutton',...
    'String','Connect','FontSize',10,'Units','normalized',...
    'Position',[0.01,0.1,0.2,0.3],'BackgroundColor','g',...
    'Callback',{@connectbutton_Callback});
connect_string = sprintf('Press for TCP/IP connection');
set(connect_button,'TooltipString',connect_string);
% Disconnection Button
disconnect_button = uicontrol(tcp_ip_panel,'Style','pushbutton',...
    'String','Disconnect','FontSize',10,'Units','normalized',...
    'Position',[0.22,0.1,0.2,0.3],'BackgroundColor','r',...
    'Callback',{@disconnectbutton_Callback});
disconnect_string = sprintf('Press for TCP/IP disconnection');
set(disconnect_button,'TooltipString',disconnect_string);
% Connection status window
connect_wind = uicontrol(tcp_ip_panel,'Style','edit','String',...
    'Disconnected.','FontSize',10,'Units','normalized',...
    'BackgroundColor','w','Position',[0.43 0.1 0.56 0.3]);
% Connection status
connection = false;
% Scale window
scale_wind = uicontrol('Parent',f,'Style','edit','String',...
    '1.0','FontSize',12,'Units','normalized',...
    'BackgroundColor','w','Position',[0.29 0.75 0.06 0.04]);
scale_string = sprintf('Linear length per revolution [mm/rev]');
set(scale_wind,'TooltipString',scale_string);
% Scale Button
confirm_button = uicontrol('Parent',f,'Style','pushbutton',...
    'String','Confirm','FontSize',10,'Units','normalized',...
    'Position',[0.39 0.75 0.10 0.04],...
    'Callback',{@confirmbutton_Callback});
scalebutton_string = sprintf('Press to confirm the linear length per revolution.');
set(confirm_button,'TooltipString',scalebutton_string);
%% Switcher field
% SW1
sw1_button = uicontrol(f,'Style','pushbutton','String','SW1',...
    'Units','normalized','Position',[0.01 0.75 0.06 0.04],...
    'FontSize',10);
set(sw1_button,'BackgroundColor','green');
sw1_string = sprintf('Indicates the status of the Switcher 1');
set(sw1_button,'TooltipString',sw1_string);
% SW2
sw2_button = uicontrol(f,'Style','pushbutton','String','SW2',...
    'Units','normalized','Position',[0.15 0.75 0.06 0.04],...
    'FontSize',10);
set(sw2_button,'BackgroundColor','green');
sw2_string = sprintf('Indicates the status of the Switcher 2');
set(sw2_button,'TooltipString',sw2_string);
%% Motor panel
% Motor panel with all necessary buttons for motor controlling
motorpanel = uipanel('Parent',f,'Title','Motor Panel','FontSize',12,...
    'Units','normalized','Position',[0.01 0.35 0.48 0.4]);
% Enabling button
enable_button = uicontrol(motorpanel,'Style','pushbutton',...
    'String','Enable','Units','normalized','Position',[0.01 0.65 0.2 0.1],...
    'FontSize',10,'Callback',{@enablebutton_Callback});
enable_string = sprintf('Press to Enable Motor');
set(enable_button,'TooltipString',enable_string);
% Disabling button
disable_button = uicontrol(motorpanel,'Style','pushbutton',...
    'String','Disable','Units','normalized','Position',[0.01 0.85 0.2 0.1],...
    'FontSize',10,'Callback',{@disablebutton_Callback});
disable_string = sprintf('Press to Disable Motor');
set(disable_button,'TooltipString',disable_string);
% Starting Button
start_button = uicontrol(motorpanel,'Style','pushbutton',...
    'String','Start','Units','normalized','Position',[0.21 0.85 0.2 0.1],...
    'FontSize',10,'Callback',{@startbutton_Callback});
start_string = sprintf('Press to Start moving Motor');
set(start_button,'TooltipString',start_string);
% Stopping Button
stop_button = uicontrol(motorpanel,'Style','pushbutton',...
    'String','Stop','Units','normalized','Position',[0.21 0.65 0.2 0.1],...
    'FontSize',10,'Callback',{@stopbutton_Callback});
stop_string = sprintf('Press to Stop moving Motor');
set(stop_button,'TooltipString',stop_string);
%
speed_text = uicontrol(motorpanel,'Style','text','String',...
    'Speed [mm/sec]:','Units','normalized',...
    'Position',[0.41 0.85 0.4 0.08]);
set(speed_text,'FontSize',10);
% Speed window
speed_wind = uicontrol(motorpanel,'Style','edit','String','1.0',...
    'FontSize',10,'BackgroundColor','w','Units','normalized',...
    'Position',[0.81 0.85 0.18 0.075]);
speed_string = sprintf('More than 0.0025 mm/sec \nLess than 10.0 mm/s');
set(speed_wind,'TooltipString',speed_string);
%
acc_text = uicontrol(motorpanel,'Style','text','String',...
    'Acceleration [mm/sec/sec]:','Units','normalized',...
    'Position',[0.41 0.65 0.4 0.08]);
set(acc_text,'FontSize',10);
% Acceleration window
acc_wind = uicontrol(motorpanel,'Style','edit','String','0.25',...
    'FontSize',10,'BackgroundColor','w','Units','normalized',...
    'Position',[0.81 0.65 0.18 0.075]);
acc_string = sprintf('More than 0.0025 mm/sec/sec \nLess than Speed value');
set(acc_wind,'TooltipString',acc_string);
% Button for setting current position of the motor
setcurpos_button = uicontrol(motorpanel,'Style','pushbutton',...
    'String','Set Current Position','Units','normalized',...
    'FontSize',10,'Position',[0.01 0.45 0.4 0.1],...
    'Callback',{@setcurposbutton_Callback});
setcurpos_string = sprintf('Press for setting motor current position');
set(setcurpos_button,'TooltipString',setcurpos_string);
%
curpos_text = uicontrol(motorpanel,'Style','text','String',...
    'Position [mm]:','Units','normalized',...
    'Position',[0.41 0.45 0.4 0.08]);
set(curpos_text,'FontSize',10);
% Window for current position value
curpos_wind = uicontrol(motorpanel,'Style','edit','String','0',...
    'FontSize',10,'BackgroundColor','w','Units','normalized',...
    'Position',[0.81 0.45 0.18 0.075]);
curpos_string = sprintf('Be sure that position is correct');
set(curpos_wind,'TooltipString',curpos_string);
% Button for setting target position of the motor
settargpos_button = uicontrol(motorpanel,'Style','pushbutton',...
    'String','Set Target Position','Units','normalized',...
    'FontSize',10,'Position',[0.01 0.25 0.4 0.1],...
    'Callback',{@settargposbutton_Callback});
settargpos_string = sprintf('Press for setting motor target position');
set(settargpos_button,'TooltipString',settargpos_string);
%
targ_text = uicontrol(motorpanel,'Style','text','String',...
    'Position [mm]:','Units','normalized',...
    'Position',[0.41 0.25 0.4 0.08]);
set(targ_text,'FontSize',10);
% Window for target position value
targpos_wind = uicontrol(motorpanel,'Style','edit','String','0',...
    'FontSize',10,'BackgroundColor','w','Units','normalized',...
    'Position',[0.81 0.25 0.18 0.075]);
targpos_string = sprintf('Be sure that position is correct');
set(targpos_wind,'TooltipString',targpos_string);


% Checkbox for scanning mode
checkbox = uicontrol(motorpanel,'Style','checkbox','String',...
    'Scan mode','Value',0,'Units','normalized',...
    'Position',[0.01 0.05 0.2 0.05],'Callback',{@checkbox_Callback});
% low limit
lowlimit_text = uicontrol(motorpanel,'Style','text','String',...
    'Low limit:','Units','normalized',...
    'Position',[0.21 0.1 0.15 0.05]);
set(lowlimit_text,'FontSize',8);
lowlimit_wind = uicontrol(motorpanel,'Style','edit','String','-10',...
    'FontSize',10,'BackgroundColor','w','Units','normalized',...
    'Position',[0.21 0.01 0.15 0.075]);
lowlimit_string = sprintf('Low limit of the scanning range (in mm)');
set(lowlimit_wind,'TooltipString',lowlimit_string);
% high limit
highlimit_text = uicontrol(motorpanel,'Style','text','String',...
    'High limit:','Units','normalized',...
    'Position',[0.37 0.1 0.15 0.05]);
set(highlimit_text,'FontSize',8);
highlimit_wind = uicontrol(motorpanel,'Style','edit','String','10',...
    'FontSize',10,'BackgroundColor','w','Units','normalized',...
    'Position',[0.37 0.01 0.15 0.075]);
highlimit_string = sprintf('High limit of the scanning range (in mm)');
set(highlimit_wind,'TooltipString',highlimit_string);
% number of points
npoints_text = uicontrol(motorpanel,'Style','text','String',...
    'N points:','Units','normalized',...
    'Position',[0.53 0.1 0.15 0.05]);
set(npoints_text,'FontSize',8);
npoints_wind = uicontrol(motorpanel,'Style','edit','String','5',...
    'FontSize',10,'BackgroundColor','w','Units','normalized',...
    'Position',[0.53 0.01 0.15 0.075]);
npoints_string = sprintf('The number of points for scanning (> 0, integer)');
set(npoints_wind,'TooltipString',npoints_string);
% pause
pause_text = uicontrol(motorpanel,'Style','text','String',...
    'Pause:','Units','normalized',...
    'Position',[0.69 0.1 0.15 0.05]);
set(pause_text,'FontSize',8);
pause_wind = uicontrol(motorpanel,'Style','edit','String','60',...
    'FontSize',10,'BackgroundColor','w','Units','normalized',...
    'Position',[0.69 0.01 0.15 0.075]);
pause_string = sprintf('Waiting time in each point (> 0, in sec)');
set(pause_wind,'TooltipString',pause_string);

% Value of target position, global variable
targetpos = str2double(get(targpos_wind,'String')); 
% Enabling status
enable = false;
% Status of moving and starting
start = false;
% Target status
target = false;
% Checkbox status
scanmode = get(checkbox,'Value');
% Disable all buttons before Press Enable button
set(start_button,'Enable','off');
set(stop_button,'Enable','off');
set(disable_button,'Enable','off');
set(enable_button,'Enable','on');
set(settargpos_button,'Enable','off');
set(setcurpos_button,'Enable','off');
set(checkbox,'Enable','off');
%% Log Panel
logpanel = uipanel('Parent',f,'Title','Log window',...
    'FontSize',12,'Units','normalized','Position',[0.01 0.15 0.48 0.2]);
log_wind = uicontrol(logpanel,'Style','list','FontSize',10,...
    'Units','normalized','BackgroundColor','k','ForegroundColor','w',...
    'Position',[0.01 0.01 0.98 0.98]);
set(log_wind,'String',...
    [datestr(now,'mmmm dd, yyyy HH:MM:SS AM') ' :: New session.']);
%% Draw Panel
drawpanel = uipanel('Parent',f,'Title','Draw Panel','FontSize',12,...
             'Units','normalized','Position',[0.51 0.15 0.48 0.85]);

XYax = axes('Parent',drawpanel);
set(XYax,'Position',[0.05 0.8 0.9 0.15]);

layout = axes('Parent',drawpanel);
set(layout,'Position',[0.05 0.01 0.9 0.7]);
img = imread('1D_Translation_Stage_Layout.jpg'); 
image(img);
axis off;
%% Signature
signature_text = uicontrol('Parent',f,'Style','text','String',...
    datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),'FontAngle','italic',...
    'Units','normalized','Position',[0.01 0.01 0.48 0.04]);
set(signature_text,'FontSize',10);
%% Help button
help_button = uicontrol(f,'Style','pushbutton','String','Help',...
    'Units','normalized','Position',[0.89 0.095 0.1 0.05],...
    'FontSize',10,'Callback',{@helpbutton_Callback});
help_string = sprintf('Press to see the help information');
set(help_button,'TooltipString',help_string);
%% Conversion coefficients
LperR = str2double(get(scale_wind,'String'));       % [mm/r]
SperR = 1000.0;                                     % [stp/r]
mm2steps = SperR/LperR;
steps2mm = LperR/SperR;
%% Get status button
status_button = uicontrol(f,'Style','pushbutton','String','Get Status',...
    'Units','normalized','Position',[0.79 0.095 0.1 0.05],...
    'FontSize',10,'Callback',{@statusbutton_Callback});
status_string = sprintf('Press to see the current system status');
set(status_button,'TooltipString',status_string);
%%
movegui(f,'center');
set(f,'Visible','on');
%% TCPIP obj
% Wait bar
h = waitbar(0,'Please wait...');
steps = 250;
for step = 1:steps
    % computations take place here
    waitbar(step / steps)
end
close(h) 
%Creates a TCPIP object = t, associated with remote host = 80.
t = tcpip(get(ip_wind,'String'), 80);
exist_t = true;
%% Log file obj
% Open file to write the motors position
fid = fopen('logfile.txt', 'a+');
fprintf(fid, '%s :: New session.\n',...
    datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
%% Description of the button functions
%% CONNECT
    function connectbutton_Callback(~,~,~)
        set(connect_wind,'String','Please wait ...');
        pause(1);
        if (exist_t)
            fclose(t);
            delete(t); 
            clear t; 
            exist_t = false;
        end
        %Creates a TCPIP object = t, associated with remote host = 80.
        t = tcpip(get(ip_wind,'String'), 80);
        exist_t = true;
        % Set size of receiving buffer, if needed. 
        set(t, 'InputBufferSize', 30000);
        % Time for scanning the ethernet port 100 mks
        set(t, 'timeout', 0.1);
        % Open connection to the server.
        fopen(t);
        
        if(isvalid(t))
            connection = true;
            set(connect_wind,'String','Connected.');
            set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                ' :: Connected to ' get(ip_wind, 'String')]}));
            fprintf(fid, '%s :: Connected to %s\n',...
                datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),...
                get(ip_wind, 'String'));
        else
            connection = false;
            set(connect_wind,'String','Disconnected.');
            errordlg(['Cannot connect to ' get(ip_wind, 'String')],...
                'Connection error');
            set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                ' :: Connection error.']}));
            fprintf(fid, '%s :: Connection error.\n',...
                datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
        end
    end
%% DISCONNECT
    function disconnectbutton_Callback(~,~,~)
        fclose(t);
        delete(t); 
        clear t;
        exist_t = false;
        connection = false;
        set(connect_wind,'String','Disconnected.');
        set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
            {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
            ' :: Disconnected.']}));
        fprintf(fid, '%s :: Disconnected.\n',...
            datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));        
    end
%% CONFIRM
    function confirmbutton_Callback(~,~,~)
        LperR = str2double(get(scale_wind,'String'));   % [mm/rev]
        SperR = 1000.0;                                 % [stp/rev]
        mm2steps = SperR/LperR;
        steps2mm = LperR/SperR;
    end
%% ENABLE BUTTON
    function enablebutton_Callback(~,~,~)
        if(connection)
            fprintf(t, '?ena');
            enable = true;
            set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                ' :: Enable Motor.']}));
            fprintf(fid, '%s :: Enable Motor.\n',...
                datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
            
            set(start_button,'Enable','on');
            set(stop_button,'Enable','on');
            set(disable_button,'Enable','on');
            set(enable_button,'Enable','off');
            set(settargpos_button,'Enable','on');
            set(setcurpos_button,'Enable','on');  
            set(checkbox,'Enable','on');
        else
            errordlg('Connect, please!','Connection error');
        end
    end
%% DISABLE BUTTON
    function disablebutton_Callback(~,~,~)
        if(connection)
            fprintf(t, '?dena');
            enable = false;
            set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                ' :: Disable Motor.']}));
            fprintf(fid, '%s :: Disable Motor.\n',...
                datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
            
            set(start_button,'Enable','off');
            set(stop_button,'Enable','off');
            set(disable_button,'Enable','off');
            set(enable_button,'Enable','on');
            set(settargpos_button,'Enable','off');
            set(setcurpos_button,'Enable','off');
            set(checkbox,'Enable','off');
        else
            errordlg('Connect, please!','Connection error');
        end
    end
%% START BUTTON
    function startbutton_Callback(~,~,~)
        if(connection && enable && target && ~start && scanmode == 0)
            set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                ' :: Motor has started to move.']}));
            fprintf(fid, '%s :: Motor has started to move.\n',...
                datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
            
            start = true;
            speed = str2double(get(speed_wind,'String'))*mm2steps;
            accel = str2double(get(acc_wind,'String'))*mm2steps;
            
            if speed < 1.0
                speed = 1;
            elseif speed > 10.0*mm2steps
                speed = 10.0*mm2steps;
            end
            if accel < 1.0
                accel = 1;
            elseif accel > speed
                accel = speed;
            end
            
            fprintf(t,['?msp' num2str(int64(speed))]);
            fprintf(t,['?mac' num2str(int64(accel))]);
            
            set(speed_wind,'String',speed*steps2mm);
            set(acc_wind,'String',accel*steps2mm);
            
            if targetpos < 0
                fprintf(t,'?ndir');
            else
                fprintf(t,'?dir');
            end
            
            fprintf(t,['?mmove' num2str(int64(abs(targetpos)))]);
            
            x0 = str2double(get(curpos_wind,'String'))*mm2steps;
            distanceToGo = abs(targetpos - x0);      

            cla(XYax,'reset');                
            line([x0*steps2mm targetpos*steps2mm],[0 0],'Parent',XYax,...
                'Color','r','Marker','o','LineStyle',':');
            
            while abs(distanceToGo) > 0
                pause(0.1)
                drawnow;
                if ~start
                    break;
                end
                % SW1 status
                fprintf(t,'?sw1');
                pause(0.1);
                sw1st = '';
                while (get(t, 'BytesAvailable') > 0)
                    sw1st = fscanf(t);
                end
                if str2double(sw1st) == 0
                    set(sw1_button,'BackgroundColor','red');
                    %start = false;
                    %break;
                else
                    set(sw1_button,'BackgroundColor','green');
                end
                % SW2 status
                fprintf(t,'?sw2');
                pause(0.1);
                sw2st = '';
                while (get(t, 'BytesAvailable') > 0)
                    sw2st = fscanf(t);
                end
                if str2double(sw2st) == 0
                    set(sw2_button,'BackgroundColor','red');
                    %start = false;
                    %break;
                else
                    set(sw2_button,'BackgroundColor','green');
                end                
                
                fprintf(t,'?b');
                pause(0.5);
                inputchar = '';
                while (get(t, 'BytesAvailable') > 0)
                    inputchar = fscanf(t);
                end
                
                distanceToGo = str2double(inputchar);
                if start                    
                    x = x0 + ((targetpos - x0)/abs(targetpos ...
                        - x0))*(abs(targetpos - x0) - abs(distanceToGo)); 
                    hold(XYax,'on');
                    line(x*steps2mm,0,'Parent',XYax,'Color','b',...
                        'Marker','+','LineStyle','-');
                    %hold on;
                    set(curpos_wind,'String',num2str(x*steps2mm));

                    set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                        {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                        ' :: PosMot = ' num2str(x*steps2mm) ' mm.']}));
                    fprintf(fid, '%s :: PosMot = %12.12f mm.\n',...
                        datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),x*steps2mm);
                end
                
                if abs(distanceToGo) == 0
                    start = false;                
                end
                
                % SW1 status
                fprintf(t,'?sw1');
                pause(0.1);
                sw1st = '';
                while (get(t, 'BytesAvailable') > 0)
                    sw1st = fscanf(t);
                end
                if str2double(sw1st) == 0
                    set(sw1_button,'BackgroundColor','red');
                    %start = false;
                    %break;
                else
                    set(sw1_button,'BackgroundColor','green');
                end
                % SW2 status
                fprintf(t,'?sw2');
                pause(0.1);
                sw2st = '';
                while (get(t, 'BytesAvailable') > 0)
                    sw2st = fscanf(t);
                end
                if str2double(sw2st) == 0
                    set(sw2_button,'BackgroundColor','red');
                    %start = false;
                    %break;
                else
                    set(sw2_button,'BackgroundColor','green');
                end 
            end
            start = false;
            
            % SW1 status
            fprintf(t,'?sw1');
            pause(0.1);
            sw1st = '';
            while (get(t, 'BytesAvailable') > 0)
                sw1st = fscanf(t);
            end
            if str2double(sw1st) == 0
                set(sw1_button,'BackgroundColor','red');
                %start = false;
            else
                set(sw1_button,'BackgroundColor','green');
            end
            % SW2 status
            fprintf(t,'?sw2');
            pause(0.1);
            sw2st = '';
            while (get(t, 'BytesAvailable') > 0)
                sw2st = fscanf(t);
            end
            if str2double(sw2st) == 0
                set(sw2_button,'BackgroundColor','red');
                %start = false;
            else
                set(sw2_button,'BackgroundColor','green');
            end
            
        elseif(connection && enable && target && ~start && scanmode == 1)
            set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                ' :: Motor has started to move.']}));
            fprintf(fid, '%s :: Motor has started to move.\n',...
                datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
            
            start = true;
            speed = str2double(get(speed_wind,'String'))*mm2steps;
            accel = str2double(get(acc_wind,'String'))*mm2steps;
            
            if speed < 1.0
                speed = 1;
            elseif speed > 10.0*mm2steps
                speed = 10.0*mm2steps;
            end
            if accel < 1.0
                accel = 1;
            elseif accel > speed
                accel = speed;
            end
            
            fprintf(t,['?msp' num2str(int64(speed))]);
            fprintf(t,['?mac' num2str(int64(accel))]);
            
            set(speed_wind,'String',speed*steps2mm);
            set(acc_wind,'String',accel*steps2mm);
            
            x0 = str2double(get(curpos_wind,'String'))*mm2steps;
            pauseTime = abs(str2double(get(pause_wind,'String')));
            trajectory = x0 + linspace(...
                str2double(get(lowlimit_wind,'String')),...
                str2double(get(highlimit_wind,'String')),...
                str2double(get(npoints_wind,'String'))).*mm2steps;
            ini_num = 1;
            
            cla(XYax,'reset');                
            line([trajectory(1).*steps2mm x0*steps2mm trajectory(end).*steps2mm],...
                [0 0 0],'Parent',XYax,'Color','r','Marker','o','LineStyle',':');
            
            while ini_num <= str2double(get(npoints_wind,'String'))
                if ~start
                    break;
                end
                distanceToGo = abs(trajectory(ini_num) - x0);
                if trajectory(ini_num) < 0
                    fprintf(t,'?ndir');
                    pause(1);
                else
                    fprintf(t,'?dir');
                    pause(1);
                end

                fprintf(t,['?mmove' num2str(int64(abs(trajectory(ini_num))))]);
                pause(0.5); 
                
                while abs(distanceToGo) > 0
                    pause(0.1)
                    drawnow;
                    if ~start                       
                        break;
                    end
                    % SW1 status
                    fprintf(t,'?sw1');
                    pause(0.1);
                    sw1st = '';
                    while (get(t, 'BytesAvailable') > 0)
                        sw1st = fscanf(t);
                    end
                    if str2double(sw1st) == 0
                        set(sw1_button,'BackgroundColor','red');
                        %start = false;
                        %break;
                    else
                        set(sw1_button,'BackgroundColor','green');
                    end
                    % SW2 status
                    fprintf(t,'?sw2');
                    pause(0.1);
                    sw2st = '';
                    while (get(t, 'BytesAvailable') > 0)
                        sw2st = fscanf(t);
                    end
                    if str2double(sw2st) == 0
                        set(sw2_button,'BackgroundColor','red');
                        %start = false;
                        %break;
                    else
                        set(sw2_button,'BackgroundColor','green');
                    end 
                
                    fprintf(t,'?b');
                    pause(0.1);
                    while (get(t, 'BytesAvailable') > 0)
                        inputchar = fscanf(t);
                    end
                    distanceToGo = str2double(inputchar);

                    if start
                        x = x0+((trajectory(ini_num) - x0)/abs(trajectory(ini_num) ...
                            - x0))*(abs(trajectory(ini_num) - x0) - abs(distanceToGo));
                        disp(x)
                        hold(XYax,'on');
                        line(x*steps2mm,0,'Parent',XYax,'Color','b',...
                            'Marker','+','LineStyle','-');
                        %hold on;
                        set(curpos_wind,'String',num2str(x*steps2mm));
                        set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                            {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                            ' :: PosMot = ' num2str(x*steps2mm) ' mm.']}));
                        fprintf(fid, '%s :: PosMot = %12.12f mm.\n',...
                            datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),x*steps2mm);
                    end

                    % SW1 status
                    fprintf(t,'?sw1');
                    pause(0.1);
                    sw1st = '';
                    while (get(t, 'BytesAvailable') > 0)
                        sw1st = fscanf(t);
                    end
                    if str2double(sw1st) == 0
                        set(sw1_button,'BackgroundColor','red');
                        %start = false;
                        %break;
                    else
                        set(sw1_button,'BackgroundColor','green');
                    end
                    % SW2 status
                    fprintf(t,'?sw2');
                    pause(0.1);
                    sw2st = '';
                    while (get(t, 'BytesAvailable') > 0)
                        sw2st = fscanf(t);
                    end
                    if str2double(sw2st) == 0
                        set(sw2_button,'BackgroundColor','red');
                        %start = false;
                        %break;
                    else
                        set(sw2_button,'BackgroundColor','green');
                    end
                end
                set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                    {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                    ' :: Motor has been stopped.']}));
                fprintf(fid, '%s :: Motor has been stopped.\n',...
                    datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
                if start
                    x0 = trajectory(ini_num);
                    ini_num = ini_num + 1;

                    if ~start
                        break;
                    end
                    pTst = false;
                    if pauseTime > 600
                        fprintf(t, '?dena');
                        enable = false;
                        pause(0.1);
                        pTst = true;
                    end
                    hh = waitbar(0,['Please wait ' num2str(pauseTime) ' seconds at this point.']);
                    tic;
                    tocv = toc;
                    while tocv <= pauseTime
                        waitbar(tocv/pauseTime)
                        tocv = toc;
                        if ~start
                            break;
                        end
                    end
                    close(hh)
                    clear hh;
                    if ~start
                        break;
                    end
                    if pTst
                        fprintf(t, '?ena');
                        enable = true;
                        pause(0.1);
                    end
                end                
            end
            start = false;
        else
            errordlg('ERROR, wrong Connection or Enabling or Target position!!!','Error');
        end
        set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
            {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
            ' :: Motor has been stopped.']}));
        fprintf(fid, '%s :: Motor has been stopped.\n',...
            datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
    end
%% STOP BUTTON
    function stopbutton_Callback(~,~,~)
        start = false;        
        fprintf(t,'?mstop');
        drawnow; 
        set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
            {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
            ' :: Motor has been stopped.']}));
        fprintf(fid, '%s :: Motor has been stopped.\n',...
            datestr(now,'mmmm dd, yyyy HH:MM:SS AM'));
    end
%% SET CURRENT POSITION BUTTON
    function setcurposbutton_Callback(~,~,~)
        if(connection)
            clear choice;
            choice = questdlg('In which way?','Attention!','Manually', ...
                'From LOG file','Cancel','Cancel');
            switch choice
                case 'Manually'
                    clear curpos;
                    curpos = str2double(get(curpos_wind,'String'))*mm2steps;
                    if curpos < 0
                        fprintf(t, ['?mcpm' num2str(int64(abs(curpos)))]);
                    else
                        fprintf(t, ['?mcpp' num2str(int64(curpos))]);
                    end                    
                    set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                        {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                        ' :: Added current position for Motor is '...
                        get(curpos_wind,'String') ' mm.']}));
                    fprintf(fid,...
                        '%s :: Added current position for Motor is %s mm.\n',...
                        datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),...
                        get(curpos_wind,'String'));                                                     
                case 'From LOG file'
                    clear fileID filename pathname;
                    [filename, pathname] = uigetfile({'*.txt';'*.dat';'*.*'},...
                        'File Selector','logfile.txt');
                    fileID = fopen([pathname filename],'r');        
                    XYc1 = textscan(fileID,'%s');
                    fclose(fileID);
                    XYc2 = cellstr(XYc1{1});
                    clear XYc1;
                    SizeOfXYc2 = size(XYc2,1);
                    ii = 1;
                    h = waitbar(0,'Please wait...');
                    while ii <= SizeOfXYc2
                        if strcmp(XYc2(ii),'PosMot') && strcmp(XYc2(ii+1),'=')
                            set(curpos_wind,'String',char(XYc2(ii+2)));
                            ii = ii + 2;
                        end
                        waitbar(ii / SizeOfXYc2)
                        ii = ii + 1;
                    end
                    curpos = str2double(get(curpos_wind,'String'))*mm2steps;
                    if curpos < 0
                        fprintf(t, ['?mcpm' num2str(int64(abs(curpos)))]);
                    else
                        fprintf(t, ['?mcpp' num2str(int64(curpos))]);
                    end
                    set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                        {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                        ' :: Added current position for Motor is '...
                        get(curpos_wind,'String') ' mm.']}));
                    fprintf(fid,...
                        '%s :: Added current position for Motor is %s mm.\n',...
                        datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),...
                        get(curpos_wind,'String'));                                     
                    close(h);
                    msgbox('Done!');
                case 'Cancel'
            end
        else
            errordlg('Connect, please!','Connection error');
        end
    end
%% SET TARGET POSITION BUTTON
    function settargposbutton_Callback(~,~,~)
        if(connection)
            clear choice;
            choice = questdlg('Are you sure?','Attention!','Yes', ...
                'No','No');
            switch choice
                case 'Yes'
                    clear targetpos;
                    targetpos = str2double(get(targpos_wind,'String'));
                    line([str2double(get(curpos_wind,'String')) targetpos],...
                        [0 0],'Parent',XYax,'Color','r','Marker','o','LineStyle',':');
                    targetpos = targetpos*mm2steps;
                    target = true;
                    set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                        {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                        ' :: Added target position for Motor is '...
                        get(targpos_wind,'String') ' mm.']}));
                    fprintf(fid,...
                        '%s :: Added target position for Motor is %s mm.\n',...
                        datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),...
                        get(targpos_wind,'String'));
                case 'No'
            end            
        else
            errordlg('Connect, please!','Connection error');
        end
    end
%% CHECKBOX
    function checkbox_Callback(~,~,~)
        scanmode = get(checkbox,'Value');
        if scanmode == 1
            set(settargpos_button,'Enable','off');
            target = true;
        else
            set(settargpos_button,'Enable','on');
            target = false;
        end
    end
%% HELP BUTTON
    function helpbutton_Callback(~,~,~) 
        helpfig = figure('Visible','off','Name',...
            'Help window','Position',[450,200,400,300]);
        help_wind = uicontrol('Parent',helpfig,'Style','list','FontSize',10,...
            'Units','normalized','BackgroundColor','w','ForegroundColor','k',...
            'Position',[0.01 0.01 0.98 0.98]);
        movegui(helpfig,'center');
        set([helpfig,help_wind],'Units','normalized');
        set(helpfig,'Visible','on');
        
        clear fileID;
        fileID = fopen('readme_help.txt','r');
        tline = fgetl(fileID);
        while ischar(tline)
            set(help_wind, 'String', cat(1, get(help_wind, 'String'),{tline}));
            tline = fgetl(fileID);
        end        
        fclose(fileID);
    end
%% GET STATUS BUTTON
    function statusbutton_Callback(~,~,~)
        if(connection)
            h = waitbar(0,'Please wait...');
            stps = 1000;
            for st = 1:stps
                waitbar(st / stps)
            end
            close(h)
            
            fprintf(t,'?gcp');
            pause(0.5);
            inputchar='';
            while (get(t, 'BytesAvailable') > 0)
                inputchar = fscanf(t);
            end
            x = str2double(inputchar);
            set(curpos_wind,'String',num2str(x*steps2mm));
            
            fprintf(t,'?mst');
            pause(0.5);
            inputchar='';
            while (get(t, 'BytesAvailable') > 0)
                inputchar = fscanf(t);
            end
            set(log_wind, 'String', cat(1, get(log_wind, 'String'),...
                {[datestr(now,'mmmm dd, yyyy HH:MM:SS AM')...
                ' :: ' inputchar]}));
            
            fprintf(fid, '%s :: %s.\n',...
                datestr(now,'mmmm dd, yyyy HH:MM:SS AM'),inputchar);
            % SW11 status
            fprintf(t,'?sw1');
            pause(0.1);
            sw11st = '';
            while (get(t, 'BytesAvailable') > 0)
                sw11st = fscanf(t);
            end
            if str2double(sw11st) == 0
                set(sw1_button,'BackgroundColor','red');
            else
                set(sw1_button,'BackgroundColor','green');
            end
            % SW12 status
            fprintf(t,'?sw2');
            pause(0.1);
            sw12st = '';
            while (get(t, 'BytesAvailable') > 0)
                sw12st = fscanf(t);
            end
            if str2double(sw12st) == 0
                set(sw2_button,'BackgroundColor','red');
            else
                set(sw2_button,'BackgroundColor','green');
            end            
        else
            errordlg('Connect, please!','Connection error');
        end
    end
end
%%