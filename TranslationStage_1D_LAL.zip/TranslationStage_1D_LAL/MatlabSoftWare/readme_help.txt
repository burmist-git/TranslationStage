#! readme file 12.11.2016
This file provides help information how to use the present GUI for 
controlling 1D translation stages constructed at LAL. The information about 
how to install you can find in install_guide.txt. To run the program open 
the terminal, go to the directory where your installed the software and 
type:

./run_GUINAME.sh /path_to_the_mcr_directory/v81

Then GUI will open and you can use it. First you have to connect to Arduino 
board (in two upper windows you can find TCP/IP information/address of the 
board), click the  button "Connect", wait few seconds and in the tab 
"Information" you will see that the program connected to the board, in 
other case you will have a message about wrong address or bad connection 
(to solve it, just rerun the gui).

MAC address: 0x90 0xA2 0xDA 0x10 0x76 0xFE
IP  address: 134.158.88.2

Connection of the pins:

--> MOTOR:
Motor driver pins:

GND	--> GND
+Vdc	--> +24 V

A+	--> Green motor cable	
A-	--> Black motor cable
B+	--> Red motor cable
B-	--> Blue motor cable

PUL+	--> +5 V
PUL-	--> D3 arduino pin
DIR+	--> +5 V
DIR-	--> D4 arduino pin
ENA+	--> +5 V
ENA-	--> D5 arduino pin

SW1	--> OFF
SW2	--> OFF
SW3	--> OFF
SW4	--> OFF
SW5	--> ON
SW6	--> ON
SW7	--> ON
SW8	--> OFF

Stopper switcher:

SW1 (negative direction/down)
Red cable	--> +5 V
Blue cable	--> GND
Black cable	--> D6

SW2 (positive direction/up)
Red cable	--> +5 V
Blue cable	--> GND
Black cable	--> D7

For more information please contact us:

Andrii Natochii     natochii@lal.in2p3.fr
Leonid Burmistrov   burmist@lal.in2p3.fr 
